-- phpMyAdmin SQL Dump
--
-- Host: localhost

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

CREATE TABLE IF NOT EXISTS `cache` (
  `id` int(10) unsigned NOT NULL COMMENT 'id',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `area` varchar(10) DEFAULT NULL,
  `type` tinyint(4) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `ep_id` varchar(100) DEFAULT NULL,
  `cache` mediumtext NOT NULL COMMENT '缓存内容'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='缓存';

ALTER TABLE `cache`
  ADD PRIMARY KEY (`id`),
  ADD KEY `add_time` (`add_time`);

ALTER TABLE `cache`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',AUTO_INCREMENT=1;