<?php
include($_SERVER['DOCUMENT_ROOT']."/index.php");
?>